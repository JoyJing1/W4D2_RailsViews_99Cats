class Student < ActiveRecord::Base
  validates :first_name,
            :last_name,
            :date_of_birth,
            :cohort,
            :github_username,
            presence: true
  validates :github_username, uniqueness: true
  validates :first_name, uniqueness:
    { scope: [:last_name, :date_of_birth, :cohort, :github_username],
      message: "cannot register twice!"
    }
    
end
