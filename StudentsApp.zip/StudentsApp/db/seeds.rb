
COHORTS = ["2016-03-07 SF", "2016-01-04 SF", "2016-02-08 NY", "2015-11-30 NY"]

10.times do
  Student.create!(first_name: Faker::Name.first_name,
                  last_name: Faker::Name.last_name,
                  date_of_birth: Faker::Date.between(18.years.ago, 80.years.ago),
                  cohort: COHORTS.sample,
                  github_username: Faker::Internet.user_name)
end
