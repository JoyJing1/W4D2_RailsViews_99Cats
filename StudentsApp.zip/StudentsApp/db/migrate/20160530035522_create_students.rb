class CreateStudents < ActiveRecord::Migration
  def change
    create_table :students do |t|
      t.string :first_name, null: false
      t.string :last_name, null: false
      t.date :date_of_birth, null: false
      t.string :cohort, null: false
      t.string :github_username, null: false

      t.timestamps null: false
    end

    add_index :students, :github_username, unique: true
  end
end
